import java.io.*;
import java.lang.reflect.Array;
import java.sql.SQLOutput;
import java.text.Collator;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChangeFile {
    //疫情类
    static class Yq {
        public String Province =null;
        public String City =null;
        public int  Citynum;
        int SumNum ;
    }

    public static void main(String[] args) throws IOException {

        Scanner input = new Scanner(System.in);
        System.out.println("请输入所要读取的文件地址及名字、输出文件的名字、" + "以及指定省份名字（可不输入）：");
        String[] In = input.nextLine().split(" ");

        int count = In.length;
        //读取文件。
        FileInputStream in = new FileInputStream(In[0]);
        //解决中文乱码问题。
        InputStreamReader inReader = new InputStreamReader(in, "GBK");
        BufferedReader bufRader = new BufferedReader(inReader);

        //初始化疫情类数组对象实例
        Yq[] yq = new Yq[10000];
        for (int i = 0; i < yq.length; i++) {
            yq[i] = new Yq();
        }

        int flag = 0;  //标志。
        int CO = 0; int flag2 = 0;  //yq总长度
        int flag3 = 0;  //标记每个省的市区个数。
        int flag4 = 0; //标记省的个数。
        int sum = 0;  //计算总人数。
        String pro = null; String str = null;
        StringBuffer result = new StringBuffer();

        //分类。
            int z = 0;
            //按行读取且分类。
            while ((str = bufRader.readLine()) != null)
            {
                //按空格分隔。
                String[] line = str.split("\\s");

                //分类。
                if (!line[2].equals("0"))
                {
                    yq[z].Province = line[0].trim();
                    yq[z].City = line[1].trim();
                    yq[z].Citynum = Integer.parseInt(line[2]);
                    z++;
                    flag2 = z;
                }
            }
            bufRader.close();

        //排序。
                //计算省份总人数。
                for (int i = 0; i < flag2; i++) {
                    if (yq[i].Province.equals(yq[i+1].Province)) {
                        sum += yq[i].Citynum;
                        CO = i;

                    } else {
                        for (int j = flag3; j < CO + 2; j++) {
                            yq[j].SumNum = sum + yq[i].Citynum;
                        }
                        flag3 = CO + 2;   //少比较了两次，所以+2;
                        CO = 0;
                        sum = 0;
                    }
                }
                //人数相同按字母大小排序。
                for (int j = 0; j < flag2; j++)
                {
                    for (int i = 0; i < flag2 - j; i++) {
                        Yq temp = new Yq();
                        if (yq[i].SumNum == yq[i + 1].SumNum) {
                            if (yq[i].Citynum < yq[i + 1].Citynum) {
                                temp = yq[i];
                                yq[i] = yq[i + 1];
                                yq[i + 1] = temp;
                            }
                            //人数相同按字母大小排序。
                            else if(yq[i].Citynum == yq[i+1].Citynum)
                            {
                                int n = getCode(yq[i].City,yq[i+1].City);
                                if(n == 1)
                                {
                                    temp = yq[i];
                                    yq[i] = yq[i + 1];
                                    yq[i + 1] = temp;
                                }
                            }
                        }
                    }
                }
                int SumNum1[] = new int[1000];
                //省份排序。
                for(int i = 0, j = 0;i <flag2;i++)
                {   SumNum1[j] = yq[i].SumNum;
                    if(yq[i].SumNum!=yq[i+1].SumNum) {
                        j++;
                        flag4 = j;
                    }
                }
                for(int i = 0; i < flag4; i++)
                {
                    int temp1;
                    for(int j = 0 ;j <flag4 - i;j++)
                    {
                        if(SumNum1[j] < SumNum1[j+1])
                        {
                            temp1 = SumNum1[j];
                            SumNum1[j] = SumNum1[j + 1];
                            SumNum1[j+1] = temp1;
                        }
                    }
                }

                int CountNum = 0;
                //输入了指定省份的输出结果。
                if(count ==3)
                {
                    for(int i = 0;i < flag2; i++)
                    {
                        if(yq[i].Province.equals(In[2])) {
                            CountNum = yq[i].SumNum;
                            result.append(yq[i].City + " \t" + yq[i].Citynum + "\n");
                        }
                    }
                }
                //不输入指定省份的输出结果。
                else {
                    for (int j = 0; j < flag4; j++)
                        for (int i = 0; i < flag2; i++) {
                            if (yq[i].SumNum == SumNum1[j]) {
                                if (flag == 0) {
                                    pro = yq[i].Province;
                                    result.append(pro + " \t" + SumNum1[j] + "\n" + yq[i].City + " \t" + yq[i].Citynum + "\n");
                                    flag = 1;
                                } else {
                                    if (pro.equals(yq[i].Province))
                                        result.append(yq[i].City + " \t" + yq[i].Citynum + "\n");
                                     else {
                                        result.append("\n");
                                        pro = yq[i].Province;
                                        result.append(pro + " \t" + SumNum1[j] + "\n" + yq[i].City + " \t" + yq[i].Citynum + "\n");
                                    }
                                }
                            }
                        }
                }

            //输出文件。
        FileWriter writer;
        try
        {
            if(count == 3) {
                writer = new FileWriter(In[1]);
                writer.write(In[count - 1] + " \t"+CountNum+ '\n' + result.toString());
                writer.flush(); writer.close();
            }
            else
            {
                writer = new FileWriter(In[1]);
                writer.write(result.toString());
                writer.flush(); writer.close();
            }
        }catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    // 比较汉字函数
    public static int getCode(String s,String s1) {
        if (s == null && s.equals("") && s1==null && s1.equals(""))
            return 3; // 保护代码
        Collator collator = Collator.getInstance(Locale.CHINA);
        return collator.compare(s,s1);
    }
}



