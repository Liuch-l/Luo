
import java.io.*;

public class Repeat {

    public static void main(String[] args) throws IOException {
        //��ȡ�ļ�
        FileInputStream in =  new FileInputStream("yq_in.txt");
        //��������������⡣
        InputStreamReader inReader = new InputStreamReader(in,"GBK");
        BufferedReader bufRader = new BufferedReader(inReader);



        int flag = 0;  //��־��

        String pro = null;
        StringBuffer result =new StringBuffer();
        String str = null;


        //���ж�ȡ�ҷ��ࡣ
        while ((str = bufRader.readLine()) != null )
        {
                //���ո�ָ���
                String[] line = str.split("\\s");
                //System.out.println(line[0]);

            //���ࡣ
            if(!line[2].equals("0"))
            {
                if (flag == 0) {
                    pro = line[0];
                    result.append(pro + '\n');
                    result.append(line[1] + "  \t" + line[2] + '\n');
                    flag = 1;
                } else {

                    if (pro.equals(line[0])) {
                        result.append(line[1] + "  \t" + line[2] + '\n');
                    } else {
                        pro = line[0];
                        result.append("\n");
                        result.append(pro + "\n");
                        result.append(line[1] + "  \t" + line[2] + "\n");
                    }
                }
            }


        }
        bufRader.close();

        //�ڿ���̨��������۲�����
        System.out.println(result);

        //����ļ���
        FileWriter writer;
        try
        {
            writer = new FileWriter("yq_out.txt");
            writer.write(result.toString());
            writer.flush();
            writer.close();
        }catch (IOException e)
        {
            e.printStackTrace();
        }



    }

}
