import java.io.*;
import java.util.Scanner;

public class ChangeFile {
    public static void main(String[] args) throws IOException {

        Scanner input = new Scanner(System.in);
        System.out.println("请输入所要读取的文件地址及名字、输出文件的名字、" +
                "以及指定省份名字（可不输入）：");
        String[] In = input.nextLine().split(" ");
        //System.out.println(In[0]);
        int count = In.length;
        //System.out.println(count);
        //读取文件。
        FileInputStream in = new FileInputStream(In[0]);
        //解决中文乱码问题。
        InputStreamReader inReader = new InputStreamReader(in,"GBK");
        BufferedReader bufRader = new BufferedReader(inReader);

        int flag = 0;  //标志。
        int flag1 = 0;

        String pro = null;
        StringBuffer result = new StringBuffer();
        String str = null;


        //不输入制定省份的分类。
        if(count != 3) {


            //按行读取且分类。
            while ((str = bufRader.readLine()) != null) {
                //按空格分隔。
                String[] line = str.split("\\s");
                //System.out.println(line[0]);

                //分类。
                if (!line[2].equals("0")) {
                    if (flag == 0) {
                        pro = line[0];
                        result.append(pro + '\n');
                        result.append(line[1] + "  \t" + line[2] + '\n');
                        flag = 1;
                    } else {

                        if (pro.equals(line[0])) {
                            result.append(line[1] + "  \t" + line[2] + '\n');
                        } else {
                            pro = line[0];
                            result.append("\n");
                            result.append(pro + "\n");
                            result.append(line[1] + "  \t" + line[2] + "\n");
                        }
                    }
                }

            }
            bufRader.close();
        }

        //输入指定省份的分类。

        else if(count == 3)
            {
                String one = In[count-1];

            //按行读取且分类。
            while ((str = bufRader.readLine()) != null)
            {
                //按空格分隔。
                String[] line = str.split("\\s");
                //System.out.println(line[0]);

                //分类。
                if (!line[2].equals("0")) {
                    if(flag1 == 0 ) {
                        pro = line[0];
                        //System.out.println(pro);
                        if (pro.equals(one)) {
                            //result.append(pro + '\n');
                            result.append(line[1] + "  \t" + line[2] + '\n');
                        }
                    }
                    else {
                        if (pro.equals(one)) {
                            flag1 = 1;
                            result.append(line[1] + "  \t" + line[2] + '\n');
                        } else {
                            System.out.println("您所输入的省份不存在文件中。");
                            return;
                        }
                    }
                }


            }
            bufRader.close();
        }


        //在控制台调试输出观察结果。
        if(count == 3) {
            System.out.println(In[count-1]);
            System.out.println(result);
        }
        else System.out.println(result);

        //输出文件。
        FileWriter writer;
        try
        {
            if(count == 3) {
                writer = new FileWriter(In[1]);
                writer.write(In[count - 1] + '\n' + result.toString());
                writer.flush();
                writer.close();
            }
            else
            {
                writer = new FileWriter(In[1]);
                writer.write(result.toString());
                writer.flush();
                writer.close();
            }
        }catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
